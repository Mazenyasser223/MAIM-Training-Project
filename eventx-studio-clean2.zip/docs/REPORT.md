# EventX Studio — Report

## Overview
EventX Studio is a full-stack event management system designed for small/medium organizers.
It includes role-based access (Admin/User), events CRUD, ticket booking with seats and QR codes,
and admin analytics (revenue, tickets sold, attendee demographics).

## Architecture
- **Frontend**: React (Vite) + Tailwind + Recharts
- **Backend**: Node.js + Express
- **Database**: MongoDB (Mongoose)
- **Auth**: JWT (7-day expiry)

## Key Flows
1. **Auth** — Register/Login returns JWT + user info; token is attached to subsequent API calls.
2. **Admin** — Create/Edit/Delete events; seats auto-generated from `totalSeats`.
3. **User** — Browse events, select a seat, book a ticket. QR code is generated and attached to the ticket.
4. **Check-in** — Admin marks ticket as checked-in (`/api/tickets/checkin/:id`).
5. **Analytics** — `/api/analytics/summary` and `/api/analytics/demographics` power dashboards.

## Seeding
`npm run seed` seeds:
- Admin: `admin@eventx.com` / `Admin123!`
- User:  `user@eventx.com` / `User123!`
- 3 demo events

## Deployment Notes
- Set `CORS_ORIGIN` to your deployed client origin(s).
- Serve client separately (Vercel/Netlify). Backend on Render/Heroku/Fly/Railway.
