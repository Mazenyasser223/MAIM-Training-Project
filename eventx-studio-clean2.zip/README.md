# EventX Studio

Full‑stack Event Management System (React + Node.js + MongoDB) with Admin/User roles.

## Features
- **Admin:** login/register, events CRUD, seat allocation, QR codes, analytics (age, gender, interests, locations), summary (events, tickets, revenue, attendees).
- **User:** login/register, browse/filter events, event details, seat booking (dummy payment), My Tickets (QR), upcoming notifications.

## Tech
- Frontend: React (Vite), TailwindCSS, Recharts
- Backend: Node.js, Express, Mongoose, JWT, QRCode
- DB: MongoDB (Local/Atlas)

## Run Locally
### Backend
```bash
cd server
copy .env.example .env    # Windows (or: cp .env.example .env)
npm install
npm run seed              # optional: add demo admin/user + events
npm run dev               # http://localhost:5000
```

### Frontend
```bash
cd ../client
copy .env.example .env
npm install
npm run dev               # http://localhost:5173
```

### Demo Accounts (after seeding)
- Admin: admin@eventx.com / Admin123!
- User : user@eventx.com  / User123!

## Deploy
- Frontend → Vercel/Netlify
- Backend → Render/Heroku/Railway
- DB → MongoDB Atlas

Set env vars on the server:
```
MONGO_URI=<atlas or local uri>
JWT_SECRET=<strong secret>
CORS_ORIGIN=<your frontend url>
```
